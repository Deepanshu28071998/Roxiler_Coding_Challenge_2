class Admin::DashboardController < ApplicationController
    before_action :require_admin
  
    def index
      @total_users = User.count
      @total_stores = Store.count
      @total_ratings = Rating.count
    end
  
    private
  
    def require_admin
      redirect_to root_path unless current_user&.admin?
    end
  end
  