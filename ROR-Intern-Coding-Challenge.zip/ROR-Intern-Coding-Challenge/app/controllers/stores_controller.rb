class StoresController < ApplicationController
    def index
      @stores = Store.all.order(:name)
    end
  
    def show
      @store = Store.find(params[:id])
      @ratings = @store.ratings.includes(:user)
    end
  end
  