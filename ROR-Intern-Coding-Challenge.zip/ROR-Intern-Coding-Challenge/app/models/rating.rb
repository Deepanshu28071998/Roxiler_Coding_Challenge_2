class Rating < ApplicationRecord
    # Associations
    belongs_to :user
    belongs_to :store
  
    # Validations
    validates :rating, presence: true, inclusion: { in: 1..5 }
  end
  