class Store < ApplicationRecord
    # Associations
    has_many :ratings, dependent: :destroy
  
    # Validations
    validates :name, presence: true
    validates :address, length: { maximum: 400 }
  
    # Calculate average rating
    def calculate_average_rating
      ratings.average(:rating).to_f
    end
  end
  