class User < ApplicationRecord
    has_secure_password
    
    # Associations
    has_many :ratings, dependent: :destroy
  
    # Validations
    validates :name, presence: true, length: { in: 20..60 }
    validates :email, presence: true, uniqueness: true, format: { with: URI::MailTo::EMAIL_REGEXP }
    validates :password, length: { in: 8..16 }, format: { with: /(?=.*[A-Z])(?=.*[!@#$&*])/ }
    validates :address, length: { maximum: 400 }
  
    # Role constants
    ROLES = %w[admin normal_user store_owner].freeze
  
    def admin?
      role == 'admin'
    end
  
    def store_owner?
      role == 'store_owner'
    end
  end
  