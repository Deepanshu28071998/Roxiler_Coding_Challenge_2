Rails.application.routes.draw do
    root "stores#index"
  
    resources :users, only: [:new, :create, :edit, :update]
    resources :stores, only: [:index, :show]
    resources :ratings, only: [:create, :update]
  
    namespace :admin do
      resources :dashboard, only: [:index]
      resources :users, only: [:index, :new, :create, :edit, :update]
      resources :stores, only: [:index, :new, :create, :edit, :update]
    end
  
    get "login", to: "sessions#new"
    post "login", to: "sessions#create"
    delete "logout", to: "sessions#destroy"
  end
  