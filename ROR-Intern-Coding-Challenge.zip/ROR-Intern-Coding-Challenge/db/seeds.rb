# Create Admin User
User.create!(name: "Admin User", email: "admin@example.com", password: "Admin@123", role: "admin", address: "Admin Address")

# Create Sample Stores
5.times do |i|
  Store.create!(name: "Store #{i+1}", address: "Address #{i+1}", email: "store#{i+1}@example.com")
end

# Create Normal Users
5.times do |i|
  User.create!(name: "User #{i+1}", email: "user#{i+1}@example.com", password: "User@123", role: "normal_user", address: "User Address #{i+1}")
end
